<?php

if(isset($_GET['method'])){ // Function to check the method is set or not
	
		if($_GET['method']=='all'){   // This code is used for listing
		$alldata = file_get_contents('http://localhost/planet/fetchdata.php');
		
		echo $alldata; die;
		
		$datas=json_decode($alldata);
		
		//echo '<pre>'; print_r($datas);die; // uncomment if you want to decoded data
		
		}else if($_GET['method']=='fourth'){  // This code is used for fourth element.
		$alldata = file_get_contents('http://localhost/planet/fetchdata.php');
		$datas=json_decode($alldata);
       
		$datacount=count($datas); // Function to count the no of rows in the array.
		
					if($datacount>='4'){ // Code will run if there is fourth element in the table.
					$fourth_element=$datas[3];
					//echo '<pre>'; print_r($fourth_element); die;			// uncomment if u want to get the decoded data
					echo json_encode($fourth_element); die;
						
					}else{
					echo "Fourth element doesn't exist"; die;
					}
		}else{
		echo "Sorry!This API Method not found"; die;
		}

}else{
	echo "Sorry! API URL doesn't exist"; die;
} 

?>