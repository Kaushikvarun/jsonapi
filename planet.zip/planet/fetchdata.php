 <?php
$servername = "localhost";
$username = "root";
$password = "";

try {
    $DB = new PDO("mysql:host=$servername;dbname=planet", $username, $password);
    // set the PDO error mode to exception
    $DB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connected successfully";
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

// Query to fetch the all the records from the planet table
$planetsql=" select * from planet_master";
$planetstmt=$DB->prepare($planetsql);
$planetstmt->execute();
$planetdata=$planetstmt->fetchAll();

echo json_encode($planetdata); // code used to resut the json encoded data
	
?> 